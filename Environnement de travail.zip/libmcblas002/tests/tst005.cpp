#include <iostream>
#include <cinttypes>
#include <mcblas0.hpp>
#include <mcblas3.hpp>
#include <tst.hpp>
//#include "test.hpp"

int main(int argc, char **argv)
{
  int res=0;

  res = test(argc, argv);

  return res;
}
